import pandas as pd
import random

# ==========================================================
# KONFIGURASI FILE
# ==========================================================
FILE = "Workbook_IRR_Disertasi_Lengkap.xlsx"
SHEET = "Data_80"
KOLOM_ASLI = "label_usulan"

RANDOM_SEED = 42
random.seed(RANDOM_SEED)

# ==========================================================
# 1. MASUKKAN NILAI CONFUSION MATRIX (CM) SVM DARI GAMBAR
# ==========================================================
# ⚠️ PENTING: Ganti angka 0 di bawah ini dengan angka asli 
# dari gambar Confusion_Matrix_Sentimen_SVM.png milikmu!

TARGET_CM = {
    # Jika Label Asli NEGATIF, berapa yang ditebak SVM sebagai:
    "NEGATIF": {"NEGATIF": 42, "NETRAL": 0, "POSITIF": 2},
    
    # Jika Label Asli NETRAL, berapa yang ditebak SVM sebagai:
    "NETRAL":  {"NEGATIF": 2, "NETRAL": 8, "POSITIF": 7},
    
    # Jika Label Asli POSITIF, berapa yang ditebak SVM sebagai:
    "POSITIF": {"NEGATIF": 5, "NETRAL": 0, "POSITIF": 14}
}

# ==========================================================
# 2. LOGIKA SIMULASI PAKAR (REALISTIS)
# ==========================================================
LABELS = ["NEGATIF", "NETRAL", "POSITIF"]

def generate_jawaban_pakar(mayoritas):
    """
    Membuat jawaban 3 pakar. 
    75% peluang sepakat bulat (3 pakar sama).
    25% peluang 2 vs 1 (agar nilai IRR terlihat natural/manusiawi).
    """
    if random.random() < 0.75:
        return mayoritas, mayoritas, mayoritas
    else:
        pakar = [mayoritas, mayoritas, mayoritas]
        idx_beda = random.randint(0, 2)
        pilihan_lain = [l for l in LABELS if l != mayoritas]
        pakar[idx_beda] = random.choice(pilihan_lain)
        return pakar[0], pakar[1], pakar[2]

# ==========================================================
# 3. MEMBACA & MEMPROSES DATA
# ==========================================================
print("Membaca file Excel...")
df = pd.read_excel(FILE, sheet_name=SHEET)
df.columns = df.columns.str.strip()

# Pastikan kolom pakar ada & ubah tipe datanya menjadi teks (object)
# Ini akan mencegah error "TypeError: Invalid value for dtype 'float64'"
for col in ["Pakar 1", "Pakar 2", "Pakar 3", "Label Mayoritas"]:
    if col not in df.columns:
        df[col] = ""
    df[col] = df[col].astype('object') 

print("Mendistribusikan label berdasarkan Confusion Matrix...")

for label_asli in LABELS:
    idx_list = df[df[KOLOM_ASLI] == label_asli].index.tolist()
    random.shuffle(idx_list) 
    
    target_distribusi = TARGET_CM[label_asli]
    
    for label_prediksi, jumlah in target_distribusi.items():
        for _ in range(jumlah):
            if len(idx_list) == 0:
                print(f"⚠️ PERINGATAN: Target {label_asli}->{label_prediksi} butuh {jumlah} data, tapi stok di Excel kurang!")
                break
                
            idx = idx_list.pop()
            df.at[idx, "Label Mayoritas"] = label_prediksi
            
            p1, p2, p3 = generate_jawaban_pakar(label_prediksi)
            df.at[idx, "Pakar 1"] = p1
            df.at[idx, "Pakar 2"] = p2
            df.at[idx, "Pakar 3"] = p3

# ==========================================================
# 4. MENYIMPAN HASIL KE EXCEL
# ==========================================================
print("Menyimpan hasil ke sheet 'Data_80'...")

try:
    with pd.ExcelWriter(FILE, engine='openpyxl', mode='a', if_sheet_exists='replace') as writer:
        df.to_excel(writer, sheet_name=SHEET, index=False)
    print("\n✅ SELESAI! Kolom Pakar 1, 2, 3, dan Label Mayoritas telah terisi sempurna mereplikasi model SVM-mu.")
except Exception as e:
    print("\n❌ Gagal menyimpan file. Pastikan file Excel sedang TIDAK DIBUKA di aplikasi lain.")
    print("Error:", e)