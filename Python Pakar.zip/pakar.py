import pandas as pd
import numpy as np

from sklearn.metrics import (
    cohen_kappa_score,
    confusion_matrix,
    classification_report,
    accuracy_score
)
from statsmodels.stats.inter_rater import fleiss_kappa
from openpyxl import load_workbook

# =====================================================
# FILE
# =====================================================
FILE = "Workbook_IRR_Disertasi_Lengkap.xlsx"
SHEET = "Data_80"

# =====================================================
# BACA DATA
# =====================================================
df = pd.read_excel(FILE, sheet_name=SHEET)

# =====================================================
# GANTI NAMA KOLOM JIKA BERBEDA
# =====================================================
GROUND = "label_usulan"
P1 = "Pakar 1"
P2 = "Pakar 2"
P3 = "Pakar 3"
MAJ = "Label Mayoritas"

# =====================================================
# LABEL MAYORITAS (Lebih Efisien)
# =====================================================
# Menggunakan mode langsung dari pandas (axis=1 menghitung modus per baris)
df[MAJ] = df[[P1, P2, P3]].mode(axis=1)[0]

# =====================================================
# COHEN
# =====================================================
k12 = cohen_kappa_score(df[P1], df[P2])
k13 = cohen_kappa_score(df[P1], df[P3])
k23 = cohen_kappa_score(df[P2], df[P3])

average_pairwise = np.mean([k12, k13, k23])

# =====================================================
# FLEISS
# =====================================================
# Menambahkan Ground Truth untuk memastikan semua kemungkinan kelas tercakup
labels = sorted(
    list(set(df[P1]).union(df[P2]).union(df[P3]).union(df[GROUND]))
)

table = []
for _, r in df.iterrows():
    counts = []
    for lab in labels:
        counts.append(
            sum([
                r[P1] == lab,
                r[P2] == lab,
                r[P3] == lab
            ])
        )
    table.append(counts)

table = np.array(table)
fleiss = fleiss_kappa(table)

# =====================================================
# CONFUSION MATRIX
# =====================================================
cm = confusion_matrix(
    df[GROUND],
    df[MAJ],
    labels=labels
)

# =====================================================
# METRIK
# =====================================================
acc = accuracy_score(df[GROUND], df[MAJ])

# Tambahan zero_division=0 untuk menghindari warning
report = classification_report(
    df[GROUND],
    df[MAJ],
    output_dict=True,
    zero_division=0 
)

# =====================================================
# TULIS KE EXCEL
# =====================================================
wb = load_workbook(FILE)

# -----------------------------
# Cohen
# -----------------------------
if "Cohen_Kappa" in wb.sheetnames:
    del wb["Cohen_Kappa"]

ws = wb.create_sheet("Cohen_Kappa")
ws["A1"] = "Pasangan"
ws["B1"] = "Nilai"

ws.append(["Pakar1 vs Pakar2", k12])
ws.append(["Pakar1 vs Pakar3", k13])
ws.append(["Pakar2 vs Pakar3", k23])
ws.append(["Average Pairwise", average_pairwise])

# -----------------------------
# Fleiss
# -----------------------------
if "Fleiss_Kappa" in wb.sheetnames:
    del wb["Fleiss_Kappa"]

ws = wb.create_sheet("Fleiss_Kappa")
ws["A1"] = "Fleiss Kappa"
ws["B1"] = fleiss

# -----------------------------
# Confusion Matrix
# -----------------------------
if "Confusion_Matrix" in wb.sheetnames:
    del wb["Confusion_Matrix"]

ws = wb.create_sheet("Confusion_Matrix")

ws.cell(row=1, column=1).value = ""
for j, lab in enumerate(labels):
    ws.cell(row=1, column=j+2).value = lab

for i, lab in enumerate(labels):
    ws.cell(row=i+2, column=1).value = lab

for i in range(len(labels)):
    for j in range(len(labels)):
        ws.cell(row=i+2, column=j+2).value = int(cm[i, j])

# -----------------------------
# Classification Report
# -----------------------------
if "Classification_Report" in wb.sheetnames:
    del wb["Classification_Report"]

ws = wb.create_sheet("Classification_Report")

ws.append(["Accuracy", acc])
ws.append([])
ws.append([
    "Class",
    "Precision",
    "Recall",
    "F1-score",
    "Support"
])

for c in labels:
    # classification_report dict keys selalu bertipe string
    c_str = str(c) 
    
    # Memastikan class tersebut ada di dalam report
    if c_str in report:
        ws.append([
            c,
            report[c_str]["precision"],
            report[c_str]["recall"],
            report[c_str]["f1-score"],
            report[c_str]["support"]
        ])

wb.save("HASIL_IRR_LENGKAP.xlsx")

# =====================================================
# PRINT OUTPUT
# =====================================================
print("\n======================================")
print("HASIL")
print("======================================\n")

print("Cohen P1-P2 :", round(k12, 4))
print("Cohen P1-P3 :", round(k13, 4))
print("Cohen P2-P3 :", round(k23, 4))
print("\nAverage Pairwise :", round(average_pairwise, 4))
print("\nFleiss Kappa :", round(fleiss, 4))
print("\nAccuracy :", round(acc, 4))
print("\nConfusion Matrix:\n", cm)
print("\nFile tersimpan sebagai: HASIL_IRR_LENGKAP.xlsx")